import React from 'react';
import { 
  FileUp, 
  FileMinus, 
  FileText, 
  FileImage, 
  FileLock2, 
  FileSignature,
  SplitSquareHorizontal,
  Merge,
  RotateCw
} from 'lucide-react';

interface ToolCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ToolCard: React.FC<ToolCardProps> = ({ icon, title, description }) => (
  <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300 cursor-pointer border border-gray-100">
    <div className="flex flex-col items-center text-center">
      <div className="text-blue-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600 text-sm">{description}</p>
    </div>
  </div>
);

function App() {
  const tools = [
    {
      icon: <Merge className="w-8 h-8" />,
      title: "Merge PDF",
      description: "Combine multiple PDFs into one file"
    },
    {
      icon: <SplitSquareHorizontal className="w-8 h-8" />,
      title: "Split PDF",
      description: "Separate one PDF into multiple files"
    },
    {
      icon: <FileMinus className="w-8 h-8" />,
      title: "Compress PDF",
      description: "Reduce file size while maintaining quality"
    },
    {
      icon: <FileImage className="w-8 h-8" />,
      title: "PDF to Image",
      description: "Convert PDF to JPG, PNG or TIFF"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "PDF to Word",
      description: "Convert PDF to editable Word document"
    },
    {
      icon: <FileLock2 className="w-8 h-8" />,
      title: "Protect PDF",
      description: "Encrypt PDF with a password"
    },
    {
      icon: <RotateCw className="w-8 h-8" />,
      title: "Rotate PDF",
      description: "Rotate PDF pages easily"
    },
    {
      icon: <FileSignature className="w-8 h-8" />,
      title: "Sign PDF",
      description: "Add digital signature to PDF"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <div className="bg-blue-600 text-white">
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Every tool you need to work with PDFs in one place
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use!
            </p>
            <div className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center justify-center space-x-4">
                <FileUp className="w-8 h-8 text-blue-600" />
                <p className="text-gray-600 text-lg">Drop your files here or click to browse</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tools Grid */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-12">All PDF Tools</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <ToolCard
              key={index}
              icon={tool.icon}
              title={tool.title}
              description={tool.description}
            />
          ))}
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our PDF Tools?</h2>
            <p className="text-gray-600">Powerful features that make PDF handling a breeze</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileUp className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Easy to Use</h3>
              <p className="text-gray-600">Simple drag and drop interface for all your PDF needs</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileLock2 className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">100% Secure</h3>
              <p className="text-gray-600">Your files are automatically deleted after 2 hours</p>
            </div>
            <div className="text-center p-6">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">High Quality</h3>
              <p className="text-gray-600">Maintain the quality of your PDF files</p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-lg font-semibold mb-4">PDF Tools</h4>
              <ul className="space-y-2">
                <li>Merge PDF</li>
                <li>Split PDF</li>
                <li>Compress PDF</li>
                <li>Convert PDF</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2">
                <li>About Us</li>
                <li>Features</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>FAQ</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
              <ul className="space-y-2">
                <li>Twitter</li>
                <li>Facebook</li>
                <li>LinkedIn</li>
                <li>Instagram</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-700 text-center">
            <p>&copy; 2024 PDF Tools. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;